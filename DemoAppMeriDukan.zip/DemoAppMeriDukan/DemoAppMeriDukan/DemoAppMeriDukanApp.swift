//
//  DemoAppMeriDukanApp.swift
//  DemoAppMeriDukan
//
//  Created by IOSDEV1 on 13/08/21.
//

import SwiftUI

@main
struct DemoAppMeriDukanApp: App {
    var body: some Scene {
        WindowGroup {
            SignUp_Screen()
        }
    }
}
